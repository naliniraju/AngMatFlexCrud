import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FarmersgeojsonDataComponent } from './farmersgeojson-data.component';

describe('FarmersgeojsonDataComponent', () => {
  let component: FarmersgeojsonDataComponent;
  let fixture: ComponentFixture<FarmersgeojsonDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FarmersgeojsonDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FarmersgeojsonDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
