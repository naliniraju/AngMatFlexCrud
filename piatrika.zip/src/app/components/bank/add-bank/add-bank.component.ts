import { Component, OnInit } from '@angular/core';
import { Bank } from 'src/app/models/bank';
import { BankService } from 'src/app/services/bank/bank.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';


@Component({
  selector: 'app-add-bank',
  templateUrl: './add-bank.component.html',
  styleUrls: ['./add-bank.component.css']
})
export class AddBankComponent implements OnInit {

  mybank: Bank = new Bank();
  submitted = false;
  banks: Bank[];
  //createForm: FormGroup;
  // bank = new FormControl('', [Validators.required]);
  // branch_address = new FormControl('', [Validators.required]);
  // bank_code = new FormControl('', [Validators.required]);


  // getErrorMessage() {
  //   this.bank.hasError('required') ? 'You must enter a value' :this.bank.hasError('bank') ? 'Not a valid text' : '';
  //   this.bank_code.hasError('required') ? 'You must enter a value' :this.bank_code.hasError('bank_code') ? 'Not a valid text' : '';
  //   this.branch_address.hasError('required') ? 'You must enter a value' :this.branch_address.hasError('branch_address') ? 'Not a valid text' : '';

  // }
  
  ngOnInit(){
    
  }

  constructor(
    private bankService: BankService,
    private router: Router,
    private location: Location,
    private fb: FormBuilder
  ) { }
 
  newBank(): void {
    this.submitted = false;
    this.mybank = new Bank();
  }

  addBankDetail() {
    this.submitted = true;
    
    this.save();
  }

  save(): void {
    console.log(this.mybank);

    this.bankService.addBankDetail(this.mybank)
      .subscribe();
    this.getBankDetails();
    //this.location.back();
    this.router.navigateByUrl('/banks');
  }

  getBankDetails() {
    return this.bankService.getBankDetails()
      .subscribe(
        banks => {
          console.log(banks);
          this.banks = banks;
        }
      );
  }
 
}
