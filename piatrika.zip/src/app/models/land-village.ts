export class LandVillage {
    id:number;
    land_village_code:string;
    land_village:string;
    village_id:number;
    plot_no:string;
    distance:string;
    east:string;
    west:string;
    north:string;
    south:string;
}
