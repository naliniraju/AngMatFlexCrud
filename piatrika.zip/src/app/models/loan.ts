export class Loan {
    id:number;
    sb_acno:string;
    loan_no:string;
    ledger_no:string;
    loan_ac_ledger_no:string;
    folio_no:string;
    loan_ac_folio_no:string;
    Farmers_id:number;
    payment_mode:string;
}
