export class Phone {
    id:number;
    phone_type:string;
    number:string;
    person_id:number;
}
